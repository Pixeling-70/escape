class_name Player 
extends CharacterBody2D



#region STATEMACHINE VARIABLES
var states : Array [PlayerState]
var current_state : PlayerState :
	get : return states.front()
var previous_state : PlayerState : 
	get : return states[1]
#endregion

#region STANDARD VARIABLES 
var direction : Vector2  = Vector2.ZERO
var gravity : float = 980.0
#endregion

func _process(_delta: float) :
	update_direction()
	change_state(current_state.process(_delta))

	
func _ready() :
	initialize_states()

func _unhandled_input(event: InputEvent) :
	change_state(current_state.handle_input(event))

func _physics_process(_delta: float) :
	velocity.y += gravity*_delta
	move_and_slide()
	change_state(current_state.physics_process(_delta))
	
func initialize_states():
	states = []
	for c in $states.get_children():
		if c is PlayerState :
			states.append(c)
			c.player = self
	
	if states.size() == 0 :
		return
	
	for state in states:
		state.init()
	change_state(current_state)

func update_direction():
	var prev_direction :Vector2 = direction
	direction = Input.get_vector("left","right","up","down")
	
	var x_axis = Input.get_axis("left","right")
	var y_axis = Input.get_axis("up","down")
	direction = Vector2(x_axis,y_axis)
	
func change_state(new_state: PlayerState):
	if new_state == null :
		return
		
	
	elif new_state == current_state :
		return
		
	if current_state:
		current_state.exit()
		
		
	states.push_front(new_state)
	current_state.enter()
	states.resize(3)
