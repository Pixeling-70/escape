class_name PlayerStateRun extends PlayerState

func init():
	pass

func enter():
	pass

func exit() :
	pass

func handle_input(_event : InputEvent )->PlayerState:
	return next_state 
	
func physics_process(_delta: float) -> PlayerState :
	return next_state 
	
func process(_delta : float ) -> PlayerState:
	return next_state 
