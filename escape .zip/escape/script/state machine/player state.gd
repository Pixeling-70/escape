class_name PlayerState
extends Node

var player : Player
var next_state : PlayerState

#region /// state reference 
@onready var idle : PlayerStateIdle = $states/idle
@onready var run : PlayerStateRun = $state/run
#endregion

func init():
	pass

func enter():
	pass

func exit():
	pass
	
func handle_input(_event : InputEvent )->PlayerState:
	if _event.is_action_pressed('jump'):
		print("jump",name)
		return $"../run"
	return next_state
	
func process(_delta):

	return next_state
		

func physics_process(_delta):
	
	return next_state
