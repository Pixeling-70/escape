extends Area2D

@onready var collision_shape: CollisionShape2D = $CollisionShape2D

# Shared tracking data across ALL room instances in your level
static var current_active_zones: Array[Area2D] = []
static var is_processing_loop_active: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node2D) -> void:
	if not is_in_group("Camera_limits"): return
	
	var camera: Camera2D = _find_camera(body)
	if camera:
		print("👉 ENTERED ZONE: ", name)
		if not current_active_zones.has(self):
			current_active_zones.append(self)
		
		_clear_rigid_camera_limits(camera)
		
		# Calculate this specific room's bounding dimensions
		var shape: RectangleShape2D = collision_shape.shape
		var center: Vector2 = collision_shape.global_position
		var half_shape: Vector2 = shape.size / 2.0
		
		var r_left: float = center.x - half_shape.x
		var r_right: float = center.x + half_shape.x
		var r_top: float = center.y - half_shape.y
		var r_bottom: float = center.y + half_shape.y
		
		# On very first room entry, set up the tracking metadata
		if not camera.has_meta("custom_cam_system"):
			camera.set_meta("custom_cam_system", true)
			camera.set_meta("target_l", r_left)
			camera.set_meta("target_r", r_right)
			camera.set_meta("target_t", r_top)
			camera.set_meta("target_b", r_bottom)
		
		# Kill any active transition tweens to prevent room overlapping fights
		if camera.has_meta("room_tween"):
			var active_tween = camera.get_meta("room_tween")
			if active_tween and active_tween.is_valid():
				active_tween.kill()
		
		# THE CINEMATIC MORPH: Smoothly glides virtual walls over 0.5 seconds
		var tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		camera.set_meta("room_tween", tween)
		
		var cur_l: float = camera.get_meta("target_l")
		var cur_r: float = camera.get_meta("target_r")
		var cur_t: float = camera.get_meta("target_t")
		var cur_b: float = camera.get_meta("target_b")
		
		tween.tween_method(func(val): camera.set_meta("target_l", val), cur_l, r_left, 0.5)
		tween.tween_method(func(val): camera.set_meta("target_r", val), cur_r, r_right, 0.5)
		tween.tween_method(func(val): camera.set_meta("target_t", val), cur_t, r_top, 0.5)
		tween.tween_method(func(val): camera.set_meta("target_b", val), cur_b, r_bottom, 0.5)
		
		if not is_processing_loop_active:
			_start_camera_tracking_loop(camera, body)

func _on_body_exited(body: Node2D) -> void:
	if not is_in_group("Camera_limits"): return
	
	var camera: Camera2D = _find_camera(body)
	if camera:
		print("👈 EXITED ZONE: ", name)
		current_active_zones.erase(self)
		
		if current_active_zones.size() == 0:
			# Player left all rooms entirely -> return camera control back to player node
			is_processing_loop_active = false
			camera.top_level = false
			camera.position = Vector2.ZERO 
		else:
			# Retarget boundaries to the remaining active room container
			var fallback_room = current_active_zones[-1]
			if is_instance_valid(fallback_room):
				fallback_room._on_body_entered(body)

func _find_camera(body: Node2D) -> Camera2D:
	var camera: Camera2D = body.get_node_or_null("Camera2D")
	if not camera:
		for child in body.get_children():
			if child is Camera2D:
				camera = child
				break
	return camera

func _clear_rigid_camera_limits(camera: Camera2D) -> void:
	camera.limit_left = -10000000
	camera.limit_right = 10000000
	camera.limit_top = -10000000
	camera.limit_bottom = 10000000

func _start_camera_tracking_loop(camera: Camera2D, player: Node2D) -> void:
	is_processing_loop_active = true
	camera.top_level = true 
	
	var tracking_lambda = func():
		if not is_processing_loop_active or not is_instance_valid(camera) or not is_instance_valid(player):
			return
			
		var target_position = player.global_position
		
		if current_active_zones.size() > 0:
			# Extract the smoothly animated boundaries out of our metadata memory
			var l = camera.get_meta("target_l")
			var r = camera.get_meta("target_r")
			var t = camera.get_meta("target_t")
			var b = camera.get_meta("target_b")
			
			var view_size = camera.get_viewport_rect().size / camera.zoom
			var half_view = view_size / 2.0
			
			# Mathematically keep player tracking position inside our smoothly changing box
			var min_x = l + half_view.x
			var max_x = r - half_view.x
			var min_y = t + half_view.y
			var max_y = b - half_view.y
			
			target_position.x = clamp(player.global_position.x, min_x, max_x)
			target_position.y = clamp(player.global_position.y, min_y, max_y)
		
		# Standard tracking glide movement speed
		camera.global_position = camera.global_position.lerp(target_position, 0.12)
		
	camera.get_tree().physics_frame.connect(tracking_lambda)
