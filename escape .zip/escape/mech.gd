extends CharacterBody2D

# --- JUMP CONFIGURATION ---
const TARGET_JUMP_HEIGHT: float = 128.0 - 32
const TIME_TO_PEAK: float = 0.27   
const TIME_TO_FALL: float = 0.23    

# --- PHYSICS MATH VALUES (Sequential ordering avoids initialization crashes) ---
var gravity_jump: float = (2.0 * TARGET_JUMP_HEIGHT) / (TIME_TO_PEAK * TIME_TO_PEAK)
var gravity_fall: float = (2.0 * TARGET_JUMP_HEIGHT) / (TIME_TO_FALL * TIME_TO_FALL)
var jump_velocity: float = -((2.0 * TARGET_JUMP_HEIGHT) / TIME_TO_PEAK)
var min_jump_velocity: float = -sqrt(2.0 * abs(gravity_jump) * MIN_JUMP_HEIGHT)

# --- HORIZONTAL MOVEMENT ---
const MAX_SPEED: float = 250.0
const ACCEL_TIME: float = 0.06         
const DECEL_TIME: float = 0.03         
const TURN_MULTIPLIER: float = 2.66

# --- GAME FEEL SYSTEMS ---
const COYOTE_TIME_MAX: float = 0.15    
const JUMP_BUFFER_MAX: float = 0.15    
const MIN_JUMP_HEIGHT: float = 32.0    

# --- SLIDE SYSTEM ---
const SLIDE_SPEED: float = 550.0
const SLIDE_DURATION: float = 0.4
const SLIDE_COOLDOWN_MAX: float = 0.4
const SLIDE_CANCEL_DECEL_TIME: float = 0.03 # ⚡ 0.03s fast brake when opposite input is pressed

# --- 🎯 SINGLE TUNING VARIABLE FOR SLIDE JUMP DISTANCE ---
const SLIDE_JUMP_FORCE: float = 400.0

# --- HEALTH & ATTACK SYSTEMS ---
@export var max_health: int = 10
@export var current_health: int = 10
@export var attack_duration: float = 0.15 

var is_attacking: bool = false

# --- NODE REFERENCES ---
@onready var weapon_anchor: Node2D = $WeaponAnchor
@onready var attack_sprite: Sprite2D = $WeaponAnchor/AttackSprite
@onready var hitbox_area: Area2D = $WeaponAnchor/Hitbox
@onready var hitbox_collision: CollisionShape2D = $WeaponAnchor/Hitbox/CollisionShape2D
@onready var sprite_node: Sprite2D = $Sprite2D

# --- STATE VARIABLES ---
var coyote_timer: float = 0.0
var jump_buffer_timer: float = 0.0
var slide_timer: float = 0.0
var slide_cooldown_timer: float = 0.0

var facing_direction: float = 1.0       
var is_sliding: bool = false
var is_slide_canceling: bool = false 
var slide_dir: float = 0.0
var was_slide_jumped: bool = false 

func _ready() -> void:
	add_to_group("player")
	if attack_sprite: attack_sprite.visible = false
	if hitbox_collision: hitbox_collision.disabled = true
	
	if hitbox_area:
		hitbox_area.body_entered.connect(_on_sword_hitbox_body_entered)

func _physics_process(delta: float) -> void:
	update_timers(delta)
	
	if Input.is_action_just_pressed("jump"):
		jump_buffer_timer = JUMP_BUFFER_MAX
	
	if is_on_floor():
		coyote_timer = COYOTE_TIME_MAX
		was_slide_jumped = false 
		is_slide_canceling = false
	else:
		apply_gravity(delta)
	
	# --- UNIFIED STATE MACHINE PATTERN ---
	if is_sliding:
		handle_slide_execution(delta)
		handle_jump()
	else:
		handle_jump()
		handle_slide_input()
		handle_horizontal_movement(delta)
		handle_attack_input()
	
	move_and_slide()

func update_timers(delta: float) -> void:
	if coyote_timer > 0.0:
		coyote_timer -= delta
	if jump_buffer_timer > 0.0:
		jump_buffer_timer -= delta
	if slide_cooldown_timer > 0.0:
		slide_cooldown_timer -= delta

func apply_gravity(delta: float) -> void:
	var current_gravity = gravity_jump if velocity.y < 0 else gravity_fall
	velocity.y += current_gravity * delta

func handle_horizontal_movement(delta: float) -> void:
	var input_dir := Input.get_axis("left", "right")
	
	if input_dir != 0.0:
		facing_direction = sign(input_dir)
		if weapon_anchor:
			weapon_anchor.scale.x = facing_direction
	
	var target_speed = input_dir * MAX_SPEED
	
	# --- SLIDE JUMP MOMENTUM & CANCEL HANDLER ---
	if was_slide_jumped and not is_on_floor():
		# ONLY CANCELS IF INPUT IS PRESSED AND IS OPPOSITE TO SLIDE DIRECTION
		if input_dir != 0.0 and sign(input_dir) != sign(slide_dir):
			was_slide_jumped = false
			is_slide_canceling = true
		elif not is_slide_canceling:
			# Firmly maintain high momentum if the player holds forward or lets go
			velocity.x = slide_dir * SLIDE_JUMP_FORCE
			return

	var rate: float = 0.0
	
	# --- HORIZONTAL SPEED INTERPOLATION ---
	if is_slide_canceling:
		# ⚡ Fast braking: drops momentum to standard movement speed limits over 0.03 seconds
		rate = SLIDE_JUMP_FORCE / SLIDE_CANCEL_DECEL_TIME
		if abs(velocity.x) <= MAX_SPEED:
			is_slide_canceling = false
	elif input_dir != 0.0:
		if sign(input_dir) != sign(velocity.x) and velocity.x != 0.0:
			rate = (MAX_SPEED / ACCEL_TIME) * TURN_MULTIPLIER
		else:
			rate = MAX_SPEED / ACCEL_TIME
	else:
		rate = MAX_SPEED / DECEL_TIME
		
	velocity.x = move_toward(velocity.x, target_speed, rate * delta)

func handle_jump() -> void:
	# Check if we are doing a dedicated slide jump or a standard jump
	if jump_buffer_timer > 0.0 and coyote_timer > 0.0:
		# 🎯 INTERCEPT INPUTS: Trigger slide jump if sliding OR if holding down on the ground
		if is_sliding or (is_on_floor() and Input.is_action_pressed("down") and slide_cooldown_timer <= 0.0):
			is_sliding = false
			slide_cooldown_timer = SLIDE_COOLDOWN_MAX
			was_slide_jumped = true 
			is_slide_canceling = false
			
			# If they held down without sliding first, use current facing direction
			if slide_dir == 0.0:
				slide_dir = facing_direction
				
			velocity.x = slide_dir * SLIDE_JUMP_FORCE 
			
		velocity.y = jump_velocity
		jump_buffer_timer = 0.0
		coyote_timer = 0.0
		
	if Input.is_action_just_released("jump") and velocity.y < min_jump_velocity:
		velocity.y = min_jump_velocity

func handle_slide_input() -> void:
	# Standard ground slide activation
	if is_on_floor() and Input.is_action_just_pressed("down") and slide_cooldown_timer <= 0.0:
		is_sliding = true
		is_slide_canceling = false
		slide_timer = SLIDE_DURATION
		slide_dir = facing_direction

func handle_slide_execution(delta: float) -> void:
	slide_timer -= delta
	velocity.x = slide_dir * SLIDE_SPEED
	
	if not is_on_floor():
		cancel_slide()
		return
		
	if slide_timer <= 0.0:
		cancel_slide()

func cancel_slide() -> void:
	is_sliding = false
	slide_cooldown_timer = SLIDE_COOLDOWN_MAX
	velocity.x = 0.0

# --- COMBAT & RESPOND HANDLING ---

func handle_attack_input() -> void:
	if Input.is_action_just_pressed("attack") and not is_attacking:
		execute_player_attack()

func execute_player_attack() -> void:
	is_attacking = true
	if attack_sprite: attack_sprite.visible = true
	if hitbox_collision: hitbox_collision.disabled = false

	await get_tree().create_timer(attack_duration).timeout
	
	if attack_sprite: attack_sprite.visible = false
	if hitbox_collision: hitbox_collision.disabled = true
	is_attacking = false

func take_damage(amount: int) -> void:
	if current_health <= 0:
		return
	
	current_health = max(0, current_health - amount)
	print("Player took damage! Remaining Health: ", current_health)
	
	if current_health <= 0:
		handle_player_death()
		return

	if sprite_node:
		var tween = create_tween().set_loops(4)
		tween.tween_property(sprite_node, "modulate", Color(5.0, 0.2, 0.2, 0.6), 0.25)
		tween.tween_property(sprite_node, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.25)

func handle_player_death() -> void:
	print("Player has died!")
	var spawn_points = get_tree().get_nodes_in_group("player_spawn_point")
	
	if spawn_points.size() > 0:
		var target_spawn = spawn_points
		global_position = target_spawn.global_position
		print("Teleported safely back to the active spawn point marker!")
		
		current_health = max_health
		velocity = Vector2.ZERO
		is_sliding = false
		is_slide_canceling = false
		was_slide_jumped = false
		slide_dir = 0.0
	else:
		print("No active custom spawn points found. Reloading level scene layout...")
		get_tree().reload_current_scene()

func _on_sword_hitbox_body_entered(body: Node) -> void:
	if body.is_in_group("boss") and body.has_method("take_damage"):
		body.take_damage(1)
