extends AnimatableBody2D

@export var slide_distance: Vector2 = Vector2(0, 225) 
@export var speed: float = 200.0

var open_position: Vector2
var closed_position: Vector2
var target_position: Vector2

var gate_locked: bool = false

func _ready():
	open_position = global_position
	closed_position = open_position + slide_distance
	target_position = open_position

func _physics_process(delta):
	# If the gate was locked down, constantly check if the boss died
	if gate_locked:
		check_boss_status()

	# Move the gate toward the target position safely
	global_position = global_position.move_toward(target_position, speed * delta)

func _on_trigger_area_body_entered(body):
	if body.is_in_group("player"):
		# 1. Slam the gate down fully
		target_position = closed_position 
		
		# 2. Lock the gate until the boss group is empty
		gate_locked = true
		
		# 3. Turn off the detector immediately to preserve gate solid collision
		if has_node("TriggerArea"):
			var area = $TriggerArea
			area.set_deferred("monitoring", false) 
			area.set_deferred("monitorable", false)
			area.queue_free() 

# NEW: Automatically check if all bosses are dead
func check_boss_status():
	var active_bosses = get_tree().get_nodes_in_group("boss")
	
	# If no bosses remain in the group, open the gate!
	if active_bosses.size() == 0:
		target_position = open_position
		gate_locked = false # Stop checking status updates
		print("Boss is dead! Gate opening...")
