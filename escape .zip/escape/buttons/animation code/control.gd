extends Node2D

## Handles professional mobile touch overlays using dynamic center-point tweening.

# Converted from 0-255 byte ranges to standard 0.0-1.0 alpha ranges
const OPACITY_RELEASED: float = 140.0 / 255.0  # ~0.55 alpha
const OPACITY_PRESSED: float = 210.0 / 255.0   # ~0.79 alpha

const SCALE_FACTOR_RELEASED: float = 1.0
const SCALE_FACTOR_PRESSED: float = 0.9  # 10% micro-shrink animation

const TWEEN_DURATION: float = 0.08  # Snappy, high-response feedback loop


func _ready() -> void:
	pass
	var _total_buttons: int = _setup_touch_buttons(self)
	#print("Initialized %d flawless touch buttons." % total_buttons)


func _setup_touch_buttons(root_node: Node) -> int:
	var count: int = 0
	for child: Node in root_node.get_children():
		if child is TouchScreenButton:
			count += 1
			_apply_touch_screen_logic(child)
			
		if child.get_child_count() > 0:
			count += _setup_touch_buttons(child)
	return count


func _apply_touch_screen_logic(btn: TouchScreenButton) -> void:
	# Set baseline transparency
	btn.modulate.a = OPACITY_RELEASED
	
	# Cache layout baselines from the Inspector
	var base_position: Vector2 = btn.position
	var base_scale: Vector2 = btn.scale
	
	# Fallback to texture dimensions if an explicit Shape2D is missing
	var button_size: Vector2 = Vector2.ZERO
	if btn.get_shape() != null:
		button_size = btn.get_shape().get_rect().size
	elif btn.texture_normal != null:
		button_size = btn.texture_normal.get_size()
		
	# Calculate visual center footprint
	var center_offset: Vector2 = (button_size * base_scale) / 2.0
	var button_center: Vector2 = base_position + center_offset
	
	# FIX 1: Use a raw variant array wrapper so [0] works safely across lambda captures
	var active_tween_container: Array = [null]
	
	# Define a unified transformation function that handles scale & position relative to center
	var apply_transformations = func(current_factor: float):
		btn.scale = base_scale * current_factor
		btn.position = button_center - (center_offset * current_factor)

	# Connect signals directly to structural lambdas
	btn.pressed.connect(func() -> void:
		if active_tween_container[0] is Tween and active_tween_container[0].is_valid():
			active_tween_container[0].kill()
			
		# FIX 2: Explicitly reference the Node2D's self context to avoid scope ambiguity inside the lambda
		var new_tween: Tween = self.create_tween().set_parallel(true)
		new_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		
		new_tween.tween_property(btn, "modulate:a", OPACITY_PRESSED, TWEEN_DURATION)
		new_tween.tween_method(apply_transformations, SCALE_FACTOR_RELEASED, SCALE_FACTOR_PRESSED, TWEEN_DURATION)
		
		active_tween_container[0] = new_tween
	)
	
	btn.released.connect(func() -> void:
		if active_tween_container[0] is Tween and active_tween_container[0].is_valid():
			active_tween_container[0].kill()
			
		# FIX 2: Explicitly reference the Node2D's self context to avoid scope ambiguity inside the lambda
		var new_tween: Tween = self.create_tween().set_parallel(true)
		new_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		
		new_tween.tween_property(btn, "modulate:a", OPACITY_RELEASED, TWEEN_DURATION)
		new_tween.tween_method(apply_transformations, SCALE_FACTOR_PRESSED, SCALE_FACTOR_RELEASED, TWEEN_DURATION)
		
		active_tween_container[0] = new_tween
	)
