extends CharacterBody2D

# Movement Speeds
@export var patrol_speed: float = 200.0
@export var charge_speed: float = 300.0 
@export var patrol_duration: float = 5.0 

# Health Settings
var max_hits: int = 10
var current_hits: int = 0

# State Tracking
enum State { PATROL, CHARGE, ATTACKING, COOLDOWN, DEAD }
var current_state: State = State.PATROL

# Internal Tracking Variables
var patrol_timer: float = 0.0
var facing_right: bool = true
var player_ref: CharacterBody2D = null

# Core Node Variables 
var sprite_node: Sprite2D = null
var weapon_sprite: Sprite2D = null
var weapon_hitbox: CollisionShape2D = null
var weapon_area: Area2D = null

# Static Hurtbox Node References
var static_anchor: Node2D = null
var static_hitbox_area: Area2D = null

func _ready():
	add_to_group("boss")
	
	# Automatically detect and store the main character texture sprite
	for child in get_children():
		if child is Sprite2D:
			sprite_node = child
	
	# Initialize the boss to its original RED color
	if sprite_node:
		sprite_node.modulate = Color(1.0, 0.0, 0.0, 1.0)
	
	# Active Swing Weapon Setup
	var weapon_anchor_node = find_child("WeaponAnchor", true, false)
	if weapon_anchor_node:
		for sub_child in weapon_anchor_node.get_children():
			if sub_child is Sprite2D:
				weapon_sprite = sub_child
			if sub_child is Area2D:
				weapon_area = sub_child
				for shape in sub_child.get_children():
					if shape is CollisionShape2D:
						weapon_hitbox = shape
						
	if weapon_sprite: weapon_sprite.visible = false
	if weapon_hitbox: weapon_hitbox.disabled = true

	if weapon_area:
		weapon_area.body_entered.connect(_on_weapon_body_entered)

	# Static Hurtbox Setup (Anchor/Hitbox/CollisionShape2D)
	static_anchor = find_child("Anchor", true, false)
	if static_anchor:
		static_hitbox_area = static_anchor.find_child("Hitbox", true, false)
		if static_hitbox_area:
			static_hitbox_area.body_entered.connect(_on_static_hurtbox_body_entered)

func _physics_process(delta):
	if current_state == State.DEAD:
		return

	if not is_on_floor():
		velocity.y += 980 * delta

	# Wall Turning Check
	if is_on_wall() and current_state == State.PATROL:
		facing_right = !facing_right
		patrol_timer = 0.0

	find_player_by_group()

	# Base AI Movement Calculations
	var ai_walk_velocity: float = 0.0

	match current_state:
		State.PATROL:
			ai_walk_velocity = patrol_speed if facing_right else -patrol_speed
			patrol_timer += delta
			if patrol_timer >= patrol_duration:
				facing_right = !facing_right
				patrol_timer = 0.0
			update_direction_visuals(1.0 if facing_right else -1.0)
			
		State.CHARGE:
			if is_instance_valid(player_ref):
				var to_player = player_ref.global_position.x - global_position.x
				var direction = sign(to_player)
				
				if direction != 0:
					ai_walk_velocity = direction * charge_speed
					update_direction_visuals(direction)
				
				if abs(to_player) < 65.0: 
					execute_attack()
			else:
				current_state = State.PATROL
				
		State.ATTACKING, State.COOLDOWN:
			ai_walk_velocity = 0.0

	velocity.x = ai_walk_velocity
	move_and_slide()

func find_player_by_group():
	if current_state == State.DEAD: return
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		player_ref = players[0]
		if global_position.distance_to(player_ref.global_position) < 350.0 and current_state == State.PATROL:
			current_state = State.CHARGE

func execute_attack():
	if current_state == State.DEAD: return
	current_state = State.ATTACKING
	
	if is_instance_valid(player_ref):
		var attack_dir = sign(player_ref.global_position.x - global_position.x)
		if attack_dir != 0:
			update_direction_visuals(attack_dir)
	
	await get_tree().create_timer(0.15).timeout
	if current_state == State.DEAD: return
	
	if weapon_sprite: weapon_sprite.visible = true
	if weapon_hitbox: weapon_hitbox.disabled = false
	
	await get_tree().create_timer(0.1).timeout
	
	if weapon_sprite: weapon_sprite.visible = false
	if weapon_hitbox: weapon_hitbox.disabled = true
	
	if current_state != State.DEAD:
		current_state = State.COOLDOWN
	
	await get_tree().create_timer(0.8).timeout
	if current_state != State.DEAD:
		current_state = State.CHARGE

func update_direction_visuals(dir: float):
	facing_right = (dir > 0)
	
	if sprite_node:
		sprite_node.flip_h = !facing_right
		
	# Mirror weapon scales on the X-axis so collision geometry turns with it
	var w_anchor = find_child("WeaponAnchor", true, false)
	if w_anchor:
		w_anchor.scale.x = 1.0 if facing_right else -1.0
		
	# Mirror secondary static hurtbox scale on the X-axis as well
	if static_anchor:
		static_anchor.scale.x = 1.0 if facing_right else -1.0

# --- COMBAT & WHITE BLINKING SYSTEM ---

func take_damage(amount: int = 1) -> void:
	if current_state == State.DEAD:
		return
		
	current_hits += amount
	print("Boss hit! Damage taken: ", current_hits, "/", max_hits)
	
	if sprite_node:
		# Instantly force the sprite into an over-exposed bright white silhouette
		sprite_node.modulate = Color(5.0, 5.0, 5.0, 1.0)
		
		# 8 loops * 0.25 seconds total = exactly 2.0 full seconds of blinking!
		var tween = create_tween().set_loops(2)
		
		# Flash back to the boss's original base RED color state
		tween.tween_property(sprite_node, "modulate", Color(1.0, 0.0, 0.0, 1.0), 0.125)
		# Flash back up into the intense glowing WHITE highlight color
		tween.tween_property(sprite_node, "modulate", Color(5.0, 5.0, 5.0, 1.0), 0.125)
		
		# Guarantee the boss returns to its base RED color when finished blinking
		tween.finished.connect(func():
			if is_instance_valid(sprite_node) and current_state != State.DEAD:
				sprite_node.modulate = Color(1.0, 0.0, 0.0, 1.0)
		)

	if current_hits >= max_hits:
		handle_death()

# Heals the boss and restores original RED color when the player dies and respawns
func reset_boss() -> void:
	if current_state != State.DEAD:
		current_hits = 0
		current_state = State.PATROL
		patrol_timer = 0.0
		if sprite_node:
			sprite_node.modulate = Color(1.0, 0.0, 0.0, 1.0)
		print("Player died! Boss health and red color restored.")

func handle_death() -> void:
	current_state = State.DEAD
	velocity = Vector2.ZERO
	print("Boss Defeated!")
	
	if weapon_sprite: weapon_sprite.visible = false
	if weapon_hitbox: weapon_hitbox.disabled = true
	
	# Disable the stationary body contact area safely on death
	if static_hitbox_area:
		var static_shape = static_hitbox_area.find_child("CollisionShape2D", true, false)
		if static_shape:
			static_shape.set_deferred("disabled", true)
	
	var boss_collision = find_child("CollisionShape2D", true, false)
	if boss_collision:
		boss_collision.set_deferred("disabled", true)
		
	if sprite_node:
		var tween = create_tween()
		# Fade to transparent from red
		tween.tween_property(sprite_node, "modulate:a", 0.0, 0.5)
		await tween.finished
		
	queue_free()

# Swinging weapon contact
func _on_weapon_body_entered(body: Node) -> void:
	if current_state == State.DEAD:
		return
		
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.take_damage(1)

# Constant touch hurtbox contact
func _on_static_hurtbox_body_entered(body: Node) -> void:
	if current_state == State.DEAD:
		return
		
	if body.is_in_group("player") and body.has_method("take_damage"):
		print("[Static Contact] Player crossed paths with the static body area.")
		body.take_damage(1)
