extends AnimatableBody2D

@export var travel_distance: Vector2 = Vector2(0, -2200) 
@export var speed: float = 600.0

var start_position: Vector2
var top_position: Vector2
var active_destination: Vector2
var player_present: bool = false
var is_waiting: bool = false # NEW: Prevents the lift from moving instantly when arriving

func _ready():
	start_position = global_position
	top_position = start_position + travel_distance
	active_destination = top_position 

func _physics_process(delta):
	# ONLY move if the player is standing on it AND the lift isn't locked/waiting
	if player_present and not is_waiting:
		global_position = global_position.move_toward(active_destination, speed * delta)
		
		# Check if the lift arrived at the destination
		if global_position.distance_to(active_destination) < 0.1:
			is_waiting = true # Lock the lift right here!
			
			# Swap the destination for the NEXT ride
			if active_destination == top_position:
				active_destination = start_position
			else:
				active_destination = top_position

# Triggered when the player steps ON the lift
func _on_player_detector_body_entered(body):
	if body.name == "Player" or body.is_in_group("player"):
		player_present = true

# Triggered when the player steps OFF the lift
func _on_player_detector_body_exited(body):
	if body.name == "Player" or body.is_in_group("player"):
		player_present = false
		is_waiting = false # NEW: Unlocks the lift so it can move next time they step on
