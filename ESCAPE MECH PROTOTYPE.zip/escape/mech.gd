extends CharacterBody2D
var damage_tween: Tween = null

# --- JUMP CONFIGURATION ---
const TARGET_JUMP_HEIGHT: float = 128.0 - 32.0
const TIME_TO_PEAK: float = 0.27
const TIME_TO_FALL: float = 0.23
const MIN_JUMP_HEIGHT: float = 32.0

# --- PHYSICS MATH VALUES ---
@onready var gravity_jump: float = (2.0 * TARGET_JUMP_HEIGHT) / (TIME_TO_PEAK * TIME_TO_PEAK)
@onready var gravity_fall: float = (2.0 * TARGET_JUMP_HEIGHT) / (TIME_TO_FALL * TIME_TO_FALL)
@onready var jump_velocity: float = -((2.0 * TARGET_JUMP_HEIGHT) / TIME_TO_PEAK)
@onready var min_jump_velocity: float = -sqrt(2.0 * abs(gravity_jump) * MIN_JUMP_HEIGHT)

# --- HORIZONTAL MOVEMENT ---
const MAX_SPEED: float = 250.0
const ACCEL_TIME: float = 0.06
const DECEL_TIME: float = 0.03
const TURN_MULTIPLIER: float = 2.66

# --- DYNAMIC SLIDE JUMP FORCES ---
const FORCE_SHORT_SLIDE_JUMP: float = 256.0 # 4 tiles (128px) if jumping early (< 0.2s)
const FORCE_LONG_SLIDE_JUMP: float = 320.0  # 5 tiles (160px) if jumping late (>= 0.2s)
var current_slide_jump_force: float = 0.0

# --- GAME FEEL SYSTEMS (BUFFERS & COYOTE) ---
const JUMP_BUFFER_MAX: float = 0.15
const ATTACK_BUFFER_MAX: float = 0.15
const SLIDE_BUFFER_MAX: float = 0.15

# --- 🎯 INDEPENDENT COYOTE TIMES ---
const COYOTE_TIME_MAX: float = 0.15          # Regular running off a ledge
const SLIDE_COYOTE_TIME_MAX: float = 0.06    # Much smaller window for sliding off a ledge

# --- SLIDE SYSTEM ---
const SLIDE_SPEED: float = 550.0
const SLIDE_DURATION: float = 0.4
const SLIDE_COOLDOWN_MAX: float = 0.6
const SLIDE_CANCEL_DECEL_TIME: float = 0.03

# --- HEALTH & ATTACK SYSTEMS ---
@export var max_health: int = 10
@export var current_health: int = 10
@export var attack_duration: float = 0.15
var is_attacking: bool = false
var attack_timer: float = 0.0

# --- NODE REFERENCES ---
@onready var weapon_anchor: Node2D = $WeaponAnchor
@onready var attack_sprite: Sprite2D = $WeaponAnchor/AttackSprite
@onready var hitbox_area: Area2D = $WeaponAnchor/Hitbox
@onready var hitbox_collision: CollisionShape2D = $WeaponAnchor/Hitbox/CollisionShape2D
@onready var sprite_node: Sprite2D = $Sprite2D

# --- STATE VARIABLES ---
var coyote_timer: float = 0.0
var slide_coyote_timer: float = 0.0 # Dedicated timer for slide jump coyote window
var jump_buffer_timer: float = 0.0
var attack_buffer_timer: float = 0.0
var slide_buffer_timer: float = 0.0

var slide_timer: float = 0.0
var slide_cooldown_timer: float = 0.0
var facing_direction: float = 1.0
var is_sliding: bool = false
var is_slide_canceling: bool = false
var slide_dir: float = 0.0
var was_slide_jumped: bool = false

func _ready() -> void:
	add_to_group("player")
	if attack_sprite:
		attack_sprite.visible = false
	if hitbox_collision:
		hitbox_collision.disabled = true
	if hitbox_area:
		hitbox_area.body_entered.connect(_on_sword_hitbox_body_entered)

func _physics_process(delta: float) -> void:
	update_timers(delta)
	handle_buffer_inputs()
	
	if is_on_floor():
		coyote_timer = COYOTE_TIME_MAX
		if is_sliding:
			# Give the smaller window when sliding on the floor right before leaving it
			slide_coyote_timer = SLIDE_COYOTE_TIME_MAX
		else:
			slide_coyote_timer = 0.0
		was_slide_jumped = false
		is_slide_canceling = false
	else:
		apply_gravity(delta)
		handle_variable_jump_release()
	
	# --- UNIFIED STATE MACHINE PATTERN ---
	if is_sliding or (slide_coyote_timer > 0.0 and not is_on_floor()):
		handle_slide_execution(delta)
		handle_jump()
	else:
		handle_jump()
		handle_slide_input()
		handle_horizontal_movement(delta)
	
	handle_attack_input()
	move_and_slide()

func update_timers(delta: float) -> void:
	if coyote_timer > 0.0:
		coyote_timer -= delta
	if slide_coyote_timer > 0.0:
		slide_coyote_timer -= delta
	if jump_buffer_timer > 0.0:
		jump_buffer_timer -= delta
	if attack_buffer_timer > 0.0:
		attack_buffer_timer -= delta
	if slide_buffer_timer > 0.0:
		slide_buffer_timer -= delta
	if slide_cooldown_timer > 0.0:
		slide_cooldown_timer -= delta
	if attack_timer > 0.0:
		attack_timer -= delta
		if attack_timer <= 0.0:
			end_attack()

func handle_buffer_inputs() -> void:
	if Input.is_action_just_pressed("jump"):
		jump_buffer_timer = JUMP_BUFFER_MAX
	if Input.is_action_just_pressed("attack"):
		attack_buffer_timer = ATTACK_BUFFER_MAX
	if Input.is_action_just_pressed("down"):
		slide_buffer_timer = SLIDE_BUFFER_MAX

func apply_gravity(delta: float) -> void:
	var current_gravity = gravity_jump if velocity.y < 0 else gravity_fall
	velocity.y += current_gravity * delta

func handle_variable_jump_release() -> void:
	if Input.is_action_just_released("jump") and velocity.y < min_jump_velocity:
		velocity.y *= 0.45

func handle_jump() -> void:
	var can_normal_jump: bool = is_on_floor() or coyote_timer > 0.0
	var can_slide_jump: bool = is_sliding or (slide_coyote_timer > 0.0 and not is_on_floor())
	
	if jump_buffer_timer > 0.0 and (can_normal_jump or can_slide_jump):
		if can_slide_jump:
			var time_spent_sliding: float = SLIDE_DURATION - slide_timer
			
			if time_spent_sliding >= 0.2:
				current_slide_jump_force = FORCE_LONG_SLIDE_JUMP
			else:
				current_slide_jump_force = FORCE_SHORT_SLIDE_JUMP
				
			is_sliding = false
			slide_coyote_timer = 0.0
			was_slide_jumped = true
			is_slide_canceling = false
			slide_dir = facing_direction if slide_dir == 0.0 else slide_dir
			
		jump_buffer_timer = 0.0
		coyote_timer = 0.0
		velocity.y = jump_velocity

func handle_slide_input() -> void:
	if slide_buffer_timer > 0.0 and is_on_floor() and slide_cooldown_timer <= 0.0:
		slide_buffer_timer = 0.0
		is_sliding = true
		was_slide_jumped = false
		is_slide_canceling = false
		slide_timer = SLIDE_DURATION
		slide_cooldown_timer = SLIDE_COOLDOWN_MAX
		slide_dir = facing_direction

func handle_slide_execution(delta: float) -> void:
	slide_timer -= delta
	velocity.x = slide_dir * SLIDE_SPEED
	
	if slide_timer <= 0.0:
		is_sliding = false
		slide_coyote_timer = 0.0
	elif not is_on_floor() and slide_coyote_timer <= 0.0 and not is_sliding:
		is_sliding = false

func handle_horizontal_movement(delta: float) -> void:
	var input_dir := Input.get_axis("left", "right")
	if input_dir != 0.0:
		facing_direction = sign(input_dir)
		if weapon_anchor:
			weapon_anchor.scale.x = facing_direction

	# --- SLIDE JUMP MOMENTUM & CANCEL HANDLER ---
	if was_slide_jumped and not is_on_floor():
		if input_dir != 0.0 and sign(input_dir) != sign(slide_dir):
			was_slide_jumped = false
			is_slide_canceling = true
		elif not is_slide_canceling:
			velocity.x = slide_dir * current_slide_jump_force
			return

	# --- HORIZONTAL SPEED INTERPOLATION ---
	var target_speed = input_dir * MAX_SPEED
	var rate: float = 0.0

	if is_slide_canceling:
		rate = current_slide_jump_force / SLIDE_CANCEL_DECEL_TIME
		if abs(velocity.x) <= MAX_SPEED:
			is_slide_canceling = false
	elif input_dir != 0.0:
		if sign(input_dir) != sign(velocity.x) and velocity.x != 0.0:
			rate = (MAX_SPEED / ACCEL_TIME) * TURN_MULTIPLIER
		else:
			rate = MAX_SPEED / ACCEL_TIME
	else:
		rate = MAX_SPEED / DECEL_TIME

	velocity.x = move_toward(velocity.x, target_speed, rate * delta)

func handle_attack_input() -> void:
	if attack_buffer_timer > 0.0 and not is_attacking:
		attack_buffer_timer = 0.0
		start_attack()

func start_attack() -> void:
	is_attacking = true
	attack_timer = attack_duration
	if attack_sprite:
		attack_sprite.visible = true
	if hitbox_collision:
		hitbox_collision.disabled = false

func end_attack() -> void:
	is_attacking = false
	if attack_sprite:
		attack_sprite.visible = false
	if hitbox_collision:
		hitbox_collision.disabled = true

func take_damage(amount: int, attacker: Node2D = null) -> void:
	current_health = clampi(current_health - amount, 0, max_health)
	
	# --- SIMPLE GENERIC RED BLINKING SYSTEM ---
	if current_health > 0 and sprite_node:
		# If a damage tween is already running from a previous hit, stop it safely
		if damage_tween and damage_tween.is_valid():
			damage_tween.kill()

		# Instantly force the player sprite to turn bright solid red
		sprite_node.modulate = Color(5.0, 0.0, 0.0, 1.0)
		
		# Create a fresh tween directly on the player node
		damage_tween = create_tween().set_loops(2)
		
		# Flash back down to normal color, then back up to neon red
		damage_tween.tween_property(sprite_node, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.125)
		damage_tween.tween_property(sprite_node, "modulate", Color(5.0, 0.0, 0.0, 1.0), 0.125)
		
		# Guarantee the player returns to clean normal colors when finished blinking
		damage_tween.finished.connect(func():
			if is_instance_valid(sprite_node) and current_health > 0:
				sprite_node.modulate = Color(1.0, 1.0, 1.0, 1.0)
		)

	if current_health <= 0:
		# Reset sprite color instantly on fatal hits so they don't look red at the spawn point
		if sprite_node:
			sprite_node.modulate = Color(1.0, 1.0, 1.0, 1.0)
			
		var safe_attacker: Node2D = null
		if is_instance_valid(attacker):
			safe_attacker = attacker
		die.call_deferred(safe_attacker)

func die(attacker: Node2D = null) -> void:
	var target_group: String = "spawn_point1" 
	
	if is_instance_valid(attacker):
		if attacker.is_in_group("boss 1"):
			target_group = "spawn_point1"
		elif attacker.is_in_group("boss 2"):
			target_group = "spawn_point2"

	var spawn_points = get_tree().get_nodes_in_group(target_group)
	
	if spawn_points.size() > 0:
		var spawn_node = spawn_points[0]
		
		# Reset mechanics
		current_health = max_health
		velocity = Vector2.ZERO
		is_sliding = false
		was_slide_jumped = false
		is_slide_canceling = false
		
		# Flush inputs so player doesn't instantly dash or jump upon spawning
		jump_buffer_timer = 0.0
		attack_buffer_timer = 0.0
		slide_buffer_timer = 0.0
		coyote_timer = 0.0
		slide_coyote_timer = 0.0
		
		# Teleport
		global_position = spawn_node.global_position
		
		# Reset engine state tracking for clean movement
		reset_physics_interpolation()
	else:
		push_warning("Spawn point group missing: " + target_group)
		get_tree().reload_current_scene()

func _on_sword_hitbox_body_entered(body: Node2D) -> void:
	if body.has_method("take_damage") and body != self:
		body.take_damage(1)
