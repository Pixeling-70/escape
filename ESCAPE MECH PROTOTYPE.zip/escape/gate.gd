extends AnimatableBody2D

@export_category("Gate Settings")
## If checked, the gate starts CLOSED. If unchecked, it starts OPEN and slams shut when triggered.
@export var starts_closed: bool = false
@export var slide_distance: Vector2 = Vector2(0, 225) 
@export var speed: float = 200.0

@export_category("Boss Tracking")
## Type the exact boss group name this gate should watch (e.g., "boss 1" or "boss 2")
@export var boss_group_to_watch: String = "boss 1"

var open_position: Vector2
var closed_position: Vector2
var target_position: Vector2

var gate_locked: bool = false

func _ready() -> void:
	open_position = global_position
	closed_position = open_position + slide_distance
	
	# Connect to the player group's death pattern if needed, or handle initial state
	reset_gate_state()

func _physics_process(delta: float) -> void:
	# Constantly check if the watched boss is dead
	if gate_locked:
		check_boss_status()

	# Move the gate smoothly
	global_position = global_position.move_toward(target_position, speed * delta)

	# --- COOLDOWN RESET CHECK ---
	# If the player died, respawned, and the boss reset, the gate must lock shut again
	if not gate_locked and target_position == open_position:
		var players = get_tree().get_nodes_in_group("player")
		if players.size() > 0:
			var player = players[0]
			# If the player died and is resetting, reset the gate too
			if player.current_health == player.max_health and get_tree().get_nodes_in_group(boss_group_to_watch).size() > 0:
				var active_boss = get_tree().get_nodes_in_group(boss_group_to_watch)[0]
				if active_boss.current_hits == 0 and not starts_closed and global_position.distance_to(open_position) < 1.0:
					reset_gate_state()

func reset_gate_state() -> void:
	if starts_closed:
		# Gate starts down/closed immediately
		global_position = closed_position
		target_position = closed_position
		gate_locked = true
		
		if has_node("TriggerArea"):
			$TriggerArea.set_deferred("monitoring", false)
	else:
		# Gate starts open normally, awaiting trigger entry
		global_position = open_position
		target_position = open_position
		gate_locked = false
		
		if has_node("TriggerArea"):
			$TriggerArea.set_deferred("monitoring", true)

func _on_trigger_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and not gate_locked:
		# Slam open gates shut when the player steps through
		target_position = closed_position 
		gate_locked = true
		
		if has_node("TriggerArea"):
			$TriggerArea.set_deferred("monitoring", false) 

func check_boss_status() -> void:
	# Looks for the custom string group configured in the inspector (e.g. "boss 1")
	var active_bosses = get_tree().get_nodes_in_group(boss_group_to_watch)
	
	# Open up once the boss group is empty
	if active_bosses.size() == 0:
		target_position = open_position
		gate_locked = false 
		print("Target boss defeated! Gate clearing the path...")
