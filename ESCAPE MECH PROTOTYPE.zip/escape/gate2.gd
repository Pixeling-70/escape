extends AnimatableBody2D

@export_category("Gate Settings")
@export var slide_distance: Vector2 = Vector2(0, -225) 
@export var speed: float = 400.0 

@export_category("Boss Tracking")
## First boss group preventing entry
@export var boss_1_group: String = "boss 1"
## Second boss group trapping the player
@export var boss_2_group: String = "boss 2" 

var open_position: Vector2 
var closed_position: Vector2 
var target_position: Vector2 

# State tracking variables
var boss_1_defeated: bool = false
var boss_2_defeated: bool = false
var player_entered_arena: bool = false

func _ready() -> void:
	open_position = global_position 
	closed_position = open_position + slide_distance 
	
	# Start CLOSED because Boss 1 is alive out front
	global_position = closed_position
	target_position = closed_position
	
	if has_node("TriggerArea"): 
		$TriggerArea.set_deferred("monitoring", true)

func _physics_process(delta: float) -> void: 
	# Smoothly move the gate toward target
	global_position = global_position.move_toward(target_position, speed * delta)
	
	# Check the status of your game flags
	check_game_progression()

func check_game_progression() -> void:
	var active_boss_1 = get_tree().get_nodes_in_group(boss_1_group)
	var active_boss_2 = get_tree().get_nodes_in_group(boss_2_group)
	
	# STAGE 1: Boss 1 is killed -> Open the door
	if not boss_1_defeated and active_boss_1.size() == 0:
		boss_1_defeated = true
		target_position = open_position
		print("Boss 1 dead! Gate opening for player entry...")

	# STAGE 3: Player has entered, now wait for Boss 2 to die -> Open the door again
	if player_entered_arena and not boss_2_defeated and active_boss_2.size() == 0:
		boss_2_defeated = true
		target_position = open_position
		print("Boss 2 dead! Gate opening permanently...")

func _on_trigger_area_body_entered(body: Node2D) -> void: 
	# STAGE 2: If Boss 1 is dead, and player steps through the collision shape -> Slam door shut
	if body.is_in_group("player") and boss_1_defeated and not player_entered_arena: 
		player_entered_arena = true
		target_position = closed_position 
		print("Player entered arena! Slamming gate shut for Boss 2 fight...")
		
		# Turn off the trigger zone so it doesn't fire again
		if has_node("TriggerArea"): 
			$TriggerArea.set_deferred("monitoring", false)
