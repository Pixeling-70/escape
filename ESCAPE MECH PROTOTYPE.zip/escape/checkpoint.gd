extends Marker2D

func _ready() -> void:
	# Add this node to a group so the player script can find it instantly
	add_to_group("player_spawn_point")

func _physics_process(_delta: float) -> void:
	# Constantly monitor the boss status every frame
	check_boss_status()

func check_boss_status() -> void:
	var active_bosses = get_tree().get_nodes_in_group("boss1")
	
	# If the boss dies (group becomes empty), make the spawn point disappear
	if active_bosses.size() == 1:
		print("Boss is dead! Spawn point disappearing...")
		queue_free() # Cleanly deletes this spawn point from the level
